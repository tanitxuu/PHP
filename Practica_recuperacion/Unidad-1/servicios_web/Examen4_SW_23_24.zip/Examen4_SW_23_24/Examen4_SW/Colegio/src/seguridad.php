<?php
$datos_env["api_session"]=$_SESSION["api_session"];
$respuesta=consumir_servicios_REST(DIR_SERV."/logueado","GET",$datos_env);
$json=json_decode($respuesta,true);
if(!$json)
{
    session_destroy();
    die(error_page("Práctica Rec 3B","<h1>Práctica Rec 3B</h1><p>Sin respuesta oportuna de la API</p>"));  
}
if(isset($json["error"]))
{

    session_destroy();
    consumir_servicios_REST(DIR_SERV."/salir","POST",$datos_env);
    die(error_page("Práctica Rec 3B","<h1>Práctica Rec 3B</h1><p>".$json["error"]."</p>"));
}

if(isset($json['no_auth']))
{
    session_unset();
    $_SESSION["seguridad"]="El tiempo de sesión de la API ha caducado";
    header("Location:".$salto);
    exit;
}
if(isset($json["mensaje"]))
{
   session_unset();
   consumir_servicios_REST(DIR_SERV."/salir","POST",$datos_env);
   $_SESSION["seguridad"]="Usted ya no se encuentra registrado en la BD";
   header("Location:".$salto);
   exit();
}
// Acabo de pasar el control de baneo
$datos_usuario_log=$json["usuario"];

if(time()-$_SESSION["ult_accion"]>MINUTOS*60)
{
    session_unset();
    $_SESSION["seguridad"]="Su tiempo de sesión ha expirado";
    header("Location:".$salto);
    exit;
}
$_SESSION["ult_accion"]=time();

?>
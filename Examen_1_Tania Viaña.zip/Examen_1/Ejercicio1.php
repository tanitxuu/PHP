<?php
function primera_linea(){
    $res="letra/desplazamiento";
    $long=26;
    for($i=1; $i <=$long; $i++) { 
        $res=";".$i;
    }
    return $res;
}
@$fd=fopen("claves_cesar.txt","w,r");
$primera_fila=primera_linea();
fputs($fd,$primera_fila.PHP_EOL);
$linea=fgets($fd);

function rellenar($fd){
    $k=ord("A");
    for ($i=1; $i <$linea ; $i++) { 
        $linea=$i;
        for ($j=1; $j <$linea ; $j++) { 
            $k++;
            if($k==chr($j)){

            }
            $k++;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="Ejercicio1.php" method="post">
    <p>
        <button type="submit" name="bt">Generar</button>
    </p>
    </form>
    <?php
    if(isset($_POST["bt"])){
        echo "<h2>Respuesta</h2>";
     
        
           echo "<textarea name='resp' id='rep'></textarea>";
    }

    ?>
</body>
</html>
<?php
$myJSON ='{"reyesgodos":[{"nombre":"Alarico","hijos":["Atanagildo","Leovigildo",{"nombre":"RecaredoI","hijos":["Sisebuto","RecaredoII",{"nombre":"Suintila","hijos":["Chindasvinto","Recesvinto","Wamba","Égica","Witiza","Rodrigo"]}]},"Sisenando","Chintila"]},"Witerico","Gundemaro"]}';
echo $myJSON;
?>
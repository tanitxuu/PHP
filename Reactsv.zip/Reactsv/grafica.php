<?php
header("Access-Control-Allow-Origin: *");

$nombre = "resultado.txt";

if (file_exists($nombre)) {
    $linea_actual = file_get_contents($nombre);
    $datos = explode("||", $linea_actual);
} else {
    die("<p>El archivo $nombre no existe</p>");
}
?>
